<div class="container">

	<?php the_content(); ?>


</div>
