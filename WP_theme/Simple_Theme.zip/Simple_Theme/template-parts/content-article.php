<div class="container">
	<header class="content-header">

		<div class="meta mb-3">
			<span class="date"><?php the_date() ?></span>

			<?php
			    the_tags('<span class="tag"><i class="fa fa-tag"></i> ', '</span><span class="tag"><i class="fa fa-tag"></i> ', '</span>');
			?>

			<span class="comment"><a href="#comments"><i class='fa fa-comment'></i> <?php comments_number(); ?></a></span>
		</div>

	</header>


	<?php the_content(); ?>


    <?php
        // $next_post_link =  get_permalink( get_adjacent_post(false,'',false)->ID );
        // $previous_post_link =  get_permalink( get_adjacent_post(false,'',true)->ID );

        $next_post_link = null;
        $nextpost = get_next_post();
        if (!empty($nextpost->ID)){
            $nextpostid = $nextpost->ID;
            $next_post_link = get_permalink( $nextpostid );
        }

        $previous_post_link = null;
        $previouspost = get_previous_post();
        if (!empty($previouspost->ID)){
            $previouspostid = $previouspost->ID;
            $previous_post_link = get_permalink( $previouspostid );
        }

    ?>


    <nav class="blog-nav nav nav-justified my-5">

        <!--Next button-->
        <?php
            if ($previous_post_link){
                ?>
                    <a class="nav-link-prev nav-item nav-link rounded-left" href="<?php echo $previous_post_link ?>">Previous<i class="arrow-prev fas fa-long-arrow-alt-left"></i></a>
                <?php
            }
        ?>

        <!--Pre button-->
	    <?php
	    if ($next_post_link){
		    ?>
                <a class="nav-link-next nav-item nav-link rounded-right" href="<?php echo $next_post_link ?>">Next<i class="arrow-next fas fa-long-arrow-alt-right"></i></a>
		    <?php
	    }
	    ?>




    </nav>
    <hr>


	<?php comments_template(); ?>

</div>
