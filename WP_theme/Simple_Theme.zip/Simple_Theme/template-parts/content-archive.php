<div class="container">

	<div class="post mb-5">
		<div class="media">
			<?php
				$link = get_the_post_thumbnail_url('','thumbnail');
				$thumbnail_id = get_post_meta( $post->ID, '_thumbnail_id', true );
				$img_alt = get_post_meta ( $thumbnail_id, '_wp_attachment_image_alt', true );

				if (! $link){
					$link = get_template_directory_uri().'/assets/images/7.jpg';
					$img_alt = get_the_title();
				}
				else{
					if(! $img_alt){
						$img_alt = get_the_title();
					}
				}

			?>

			<img class="mr-3 img-fluid post-thumb d-none d-md-flex" src="<?php echo $link ?>" alt="<?php  echo $img_alt ?>">

			<div class="media-body">
				<h3 class="title mb-1"><a href="<?php the_permalink(); ?>"><?php the_title() ?></a></h3>
				<div class="meta mb-1"><span class="date"><?php the_date() ?></span>
					<span class="time">3 min read</span>
					<span class="comment"><a href="#"><?php comments_number(); ?></a></span>
				</div>
				<div class="intro"><?php the_excerpt(); ?></div>
				<a class="more-link" href="<?php the_permalink(); ?>">Read more &rarr;</a>
			</div><!--//media-body-->
		</div><!--//media-->
	</div>

</div>
