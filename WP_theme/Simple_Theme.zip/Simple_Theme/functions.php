<?php


//**************************************************************
// theme setup
//**************************************************************

function theme_setup(){
	/** tag-title **/
	add_theme_support( 'title-tag' );
	add_theme_support('custom-logo');
	add_theme_support('post-thumbnails', array( 'post' ) ); // Posts only
//	add_image_size('mini', 100, 100, true);
}
add_action('after_setup_theme','theme_setup');



//**************************************************************
// register nav menus
//**************************************************************

function func_menus(){
	$locations = array(
		'primary' => "Desktop Primary Left Sidebar",
		'footer' => "Footer Menu Items"
	);
	register_nav_menus($locations);
}
add_action('init', "func_menus");



//**************************************************************
// add style to header
//**************************************************************

function func_register_styles(){
	$version = wp_get_theme()->get('Version');

	wp_enqueue_style('font_awesome_cdn',"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css", array(), '5.13.0', 'all');
	wp_enqueue_style('bootstrap_cdn', "https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css", array(), '4.4.1', 'all');
	wp_enqueue_style('main_style',get_template_directory_uri()."/style.css", array('bootstrap_cdn','font_awesome_cdn'), $version, 'all');
}
add_action('wp_enqueue_scripts', 'func_register_styles');



//**************************************************************
// add Script to end of body
//**************************************************************

function func_register_script(){
	wp_enqueue_script('jquery_cdn', "https://code.jquery.com/jquery-3.4.1.slim.min.js", array(), "3.4.1", true);
	wp_enqueue_script('bootstrap_cdn', "https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js", array(), "4.4.1", true);
	wp_enqueue_script('popper_cdn', "https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js", array(), "1.16.0", true);
	wp_enqueue_script('main_script', get_template_directory_uri()."/assets/js/main.js", array(), "1.0", true);
}
add_action('wp_enqueue_scripts', 'func_register_script');



//**************************************************************
// Add Footer Area widget
//**************************************************************

function func_widget_areas(){
	register_sidebar(
		array(
			'before_title' => '<h6>',
			'after_title' => '</h6>',
			'before_widget' => '<div>',
			'after_widget' => '</div>',
			'name' => 'Footer Area',
			'id' => 'side_1',
			'description' => 'Footer widget area',
		)
	);
}
add_action( 'widgets_init', 'func_widget_areas' );

function footer_area_widget( $wp_customize ) {
	$wp_customize->add_section( 'logostyle' , array(
		'title'      => __( 'لوگو و استایل', 'mytheme' ),
		'priority'   => 1,
	) );

	$wp_customize->add_setting( 'header_textcolor' , array(
		'default'   => '#000000',
		'transport' => 'refresh',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'link_color', array(
		'label'      => __( 'Header Color', 'mytheme' ),
		'section'    => 'logostyle',
		'settings'   => 'header_textcolor',
	) ) );

}
add_action( 'customize_register', 'footer_area_widget' );



//**************************************************************
// Create Custo Post Type for Slideres
//**************************************************************

function create_slider_post_type() {

	$labels = array(
		'name' => __( 'Sliders' ),
		'singular_name' => __( 'Sliders' ),
		'all_items'           => __( 'All Sliders' ),
		'view_item'           => __( 'View Slider' ),
		'add_new_item'        => __( 'Add New Slider' ),
		'add_new'             => __( 'Add New Slider' ),
		'edit_item'           => __( 'Edit Slider' ),
		'update_item'         => __( 'Update Slider' ),
		'search_items'        => __( 'Search Slider' ),
		'search_items' => __('Sliders')
	);

	$args = array(
		'labels' => $labels,
		'description' => 'Add New Slider contents',
		'menu_position' => 27,
		'public' => true,
		'has_archive' => true,
		'map_meta_cap' => true,
		'capability_type' => 'post',
		'hierarchical' => true,
		'rewrite' => array('slug' => false),
		'menu_icon'=>'dashicons-format-image',
		'supports' => array(
			'title',
			'thumbnail',
			'excerpt'
		),
	);
	register_post_type( 'slider', $args);

}
add_action( 'init', 'create_slider_post_type' );


add_action( 'init', function() {
	remove_post_type_support( 'slider', 'editor' );
	remove_post_type_support( 'slider', 'slug' );
    }
);

function cih_theme_support(){
	add_theme_support( 'post-thumbnails' );
	add_image_size( 'slider_image','1024','720',true);
}
add_action('after_setup_theme','cih_theme_support');

function remove_thumbnail_dimensions( $html, $post_id, $post_image_id ) {
	$html = preg_replace( '/(width|height)=\"\d*\"\s/', "", $html );
	return $html;
}

add_filter( 'post_thumbnail_html', 'remove_thumbnail_dimensions', 10, 3 );

function sliderLink_add_meta_box() {
	add_meta_box('slider_link','Slider Link','slider_link_callback','slider');
}

function slider_link_callback( $post ) {

	wp_nonce_field('slider_link_save','slider_link_meta_box_nonce');
	$value = get_post_meta($post->ID,'_slider_link_value_key',true);
	?>
	<input type="text" name="slider_link_field" id="slider_link_field" value="<?php echo esc_attr( $value ); ?>" required="required" size="100" />
	<?php
}
add_action('add_meta_boxes','sliderLink_add_meta_box');

function slider_link_save( $post_id ) {
	if( ! isset($_POST['slider_link_meta_box_nonce'])) {
		return;
	}
	if( ! wp_verify_nonce( $_POST['slider_link_meta_box_nonce'], 'slider_link_save') ) {
		return;
	}
	if( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) {
		return;
	}
	if( ! current_user_can('edit_post', $post_id)) {
		return;
	}
	if( ! isset($_POST['slider_link_field'])) {
		return;
	}
	$slider_link = sanitize_text_field($_POST['slider_link_field']);
	update_post_meta( $post_id,'_slider_link_value_key', $slider_link );
}
add_action('save_post','slider_link_save');



//**************************************************************
//Create Theme Options and get social media links
//**************************************************************

//register settings
function theme_options_add(){
	register_setting( 'theme_settings', 'theme_settings' );
}

//add settings page to menu
function add_options() {
	add_menu_page( __( 'Theme Options' ), __( 'Social media' ), 'manage_options', 'settings', 'theme_options_page');
}
//add actions
add_action( 'admin_init', 'theme_options_add' );
add_action( 'admin_menu', 'add_options' );

//start settings page
function theme_options_page() {

	if ( ! isset( $_REQUEST['updated'] ) )
		$_REQUEST['updated'] = false;

    //get variables outside scope
	global $color_scheme;
	?>
    <div>
        <form method="post" action="options.php">
            <h2>Social media Options</h2>
			<?php settings_fields( 'theme_settings' ); ?>
			<?php $options = get_option( 'theme_settings' ); ?>
            <table>

                <!--twitter link-->
                <tr valign="top">
                    <th scope="row"><?php _e( 'Twitter URL' ); ?></th>
                    <td>
                        <input id="theme_settings[twitterurl]" type="text" size="36" name="theme_settings[twitterurl]" value="<?php esc_attr_e ($options['twitterurl'] ); ?>" />
                        <label for="theme_settings[twitterurl]"><?php _e( 'Enter Twitter URL' ); ?></label>
                    </td>
                </tr>

                <!--linkdin link-->
                <tr valign="top">
                    <th scope="row"><?php _e( 'Linkdin URL' ); ?></th>
                    <td>
                        <input id="theme_settings[linkdinurl]" type="text" size="36" name="theme_settings[linkdinurl]" value="<?php esc_attr_e ($options['linkdinurl'] ); ?>" />
                        <label for="theme_settings[linkdinurl]"><?php _e( 'Enter Linkdin URL' ); ?></label>
                    </td>
                </tr>

                <!--github link-->
                <tr valign="top">
                    <th scope="row"><?php _e( 'Github URL' ); ?></th>
                    <td>
                        <input id="theme_settings[githuburl]" type="text" size="36" name="theme_settings[githuburl]" value="<?php if (!empty($options['githuburl'])) { esc_attr_e ($options['githuburl']); } ?>" />
                        <label for="theme_settings[githuburl]"><?php _e( 'Enter Github URL' ); ?></label>
                    </td>
                </tr>

                <!--stackoverflow link-->
                <tr valign="top">
                    <th scope="row"><?php _e( 'Stackoverflow URL' ); ?></th>
                    <td>
                        <input id="theme_settings[stackoverflowurl]" type="text" size="36" name="theme_settings[stackoverflowurl]" value="<?php if (!empty($options['stackoverflowurl'])) { esc_attr_e ($options['stackoverflowurl']); } ?>" />
                        <label for="theme_settings[stackoverflowurl]"><?php _e( 'Enter Stackoverflow URL' ); ?></label>
                    </td>
                </tr>

                <!--$codepen link-->
                <tr valign="top">
                    <th scope="row"><?php _e( 'Codepen URL' ); ?></th>
                    <td>
                        <input id="theme_settings[codepenurl]" type="text" size="36" name="theme_settings[codepenurl]" value="<?php if (!empty($options['codepenurl'])) { esc_attr_e ($options['codepenurl']); } ?>" />
                        <label for="theme_settings[codepenurl]"><?php _e( 'Enter Codepen URL' ); ?></label>
                    </td>
                </tr>

            </table>

            <p><input name="submit" id="submit" value="Save Changes" type="submit"></p>
        </form>
    </div>

	<?php
}