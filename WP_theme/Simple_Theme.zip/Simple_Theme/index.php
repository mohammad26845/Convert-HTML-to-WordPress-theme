<?php
get_header();
?>

    <div class="main-wrapper">

        <header id="page-title" class="page-title theme-bg-light text-center gradient py-5">
            <h1 class="heading">BLOG</h1>
        </header>


	<article class="content px-3 py-5 p-md-5">

		<?php
		if (have_posts()){

			while (have_posts()){

				the_post();

				get_template_part( 'template-parts/content', 'archive');

			}
		}
		?>


        <!--posts_pagination-->

		<?php
            $pagination = paginate_links( array(
                'base'               => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ), // http://example.com/all_posts.php%_% : %_% is replaced by format (below).
                'format'             => '?page=%#%', // ?page=%#% : %#% is replaced by the page number.
                'total'              => $wp_query -> max_num_pages,
                'current'            => max( 1, get_query_var('paged')),
                'aria_current'       => 'page',
                'show_all'           => false,
                'prev_next'          => true,
                'prev_text'          => '<i class="fas fa-angle-double-left"></i>',
                'next_text'          => '<i class="fas fa-angle-double-right"></i>',
                'end_size'           => 1,
                'mid_size'           => 2,
                'type'               => 'array',
                'add_fragment'       => '',
                'before_page_number' => 'Page ',
                'after_page_number'  => '',
            ) );
		?>


		<?php if ( ! empty( $pagination ) ) : ?>
            <nav class="blog-nav nav nav-justified my-5" aria-label="page" role="navigation">

                <?php
                    foreach ( $pagination as $key => $page_link ) :

                        $link = htmlspecialchars($page_link);
                        $link = str_replace( ' current', '', $link);

                        if ( $link ) {
                            $link = str_replace( 'page-numbers', 'nav-item nav-link rounded', $link);
                        }

                        echo htmlspecialchars_decode($link);

                    endforeach
                ?>

            </nav>
		<?php endif ?>



	</article>







<?php
get_footer();
?>