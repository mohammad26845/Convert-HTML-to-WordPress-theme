<?php
    get_header();
?>

    <div class="main-wrapper">
    <header class="page-title theme-bg-light text-center gradient py-5">
        <h1 class="heading"><?php the_title()  ?></h1>
    </header>




    <article class="content px-3 py-5 p-md-5">
        <div class='container'>

<!--************************************** Start slider-->
	        <?php
	        $arg = array(
		        'post_type'         => 'slider',
		        'posts_per_page'    => 3,
		        'order'             => 'ASC'
	        );
	        $slider = new WP_Query($arg);
	        $j = 0;
	        $post_count = wp_count_posts('slider')->publish;
	        ?>

            <div id="carouselExampleControls2" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
	                <?php for($i=0;$i<$post_count; $i++): ?>
                        <li data-target="#carouselExampleControls2" data-slide-to="<?php echo $i; ?>" class="active"></li>
	                <?php endfor; ?>
                </ol>

                <div class="carousel-inner">

                    <?php while($slider->have_posts()) : $slider->the_post(); ?>

                        <div class="carousel-item <?php echo $j==0 ? ' active': '';?>">
                            <a href="<?php echo get_post_meta(get_the_ID(),'_slider_link_value_key', true); ?>">

                            <?php
                                if(has_post_thumbnail()){
                                    // add img tag
                                    the_post_thumbnail('slider_image', array('class' => 'd-block w-100'));
                                }
	                        ?>

                                <div class="carousel-caption d-none d-md-block">
                                    <!--Title-->
                                    <h5><?php the_title() ?></h5>
                                    <!--Expert-->
                                    <?php the_excerpt(); ?>
                                </div>

                            </a>
                        </div>

                    <?php
                        $j++;
                        endWhile;
                        wp_reset_query();
                    ?>
                </div>

                <a class="carousel-control-prev" href="#carouselExampleControls2" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>

                <a class="carousel-control-next" href="#carouselExampleControls2" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
<!--************************************** Edn slider-->




<!--            <form id="newsletter-footer" action="" method="POST">-->
<!---->
<!--                <h5><strong>Sign up</strong> for email updates</h5>-->
<!--                <div class="newsletter-form">-->
<!--                    <div class="newsletter-email" style="margin-bottom:10px; " >-->
<!--                        <input type="email" name="subscriber_email" placeholder="Email address">-->
<!--                    </div>-->
<!---->
<!--                    <div class="newsletter-submit">-->
<!--                        <input type="hidden" name="kv_submit_subscription" value="Submit">-->
<!--                        <input type="submit" name="submit_form" value="Submit">-->
<!--                    </div>-->
<!---->
<!---->
<!--                </div>-->
<!--            </form>-->


            <section class="theme-bg-dark py-5 mt-4 text-center">
                <h3 class='text-light d-block'>Subscribe to the Newsletter</h3>

                <form id="newsletter-footer" class="signup-form form-inline justify-content-center pt-3" action="" method="POST">
                    <div class="form-group">
                        <label class="sr-only" for="semail">Your email</label>
                        <input type="email" id="semail" name="subscriber_email" class="form-control mr-md-1 semail" placeholder="Enter Email">
                    </div>


                    <input class="btn btn-primary" type="hidden" name="kv_submit_subscription" value="Submit">
                    <input class="btn btn-primary" type="submit" name="submit_form" value="Submit">


                </form>

            </section>

<!--            send email -->

            <?php
                if('POST' == $_SERVER['REQUEST_METHOD'] && isset($_POST['kv_submit_subscription'])) {

                    if( filter_var($_POST['subscriber_email'], FILTER_VALIDATE_EMAIL) ){

                        $blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);

                        $subject = sprintf(__('New Subscription on %s','kvc'), $blogname);

                        $to = get_option('admin_email');

                        $headers = 'From: '. sprintf(__('%s Admin', 'kvc'), $blogname) .' <No-repy@'.$_SERVER['SERVER_NAME'] .'>' . PHP_EOL;

                        $message  = sprintf(__('Hi ,', 'kvc')) . PHP_EOL . PHP_EOL;
                        $message .= sprintf(__('You have a new subscription on your %s website.', 'kvc'), $blogname) . PHP_EOL . PHP_EOL;
                        $message .= __('Email Details', 'kvc') . PHP_EOL;
                        $message .= __('-----------------') . PHP_EOL;
                        $message .= __('User E-mail: ', 'kvc') . stripslashes($_POST['subscriber_email']) . PHP_EOL;
                        $message .= __('Regards,', 'kvc') . PHP_EOL . PHP_EOL;
                        $message .= sprintf(__('Your %s Team', 'kvc'), $blogname) . PHP_EOL;
                        $message .= trailingslashit(get_option('home')) . PHP_EOL . PHP_EOL . PHP_EOL . PHP_EOL;


                        if (wp_mail($to, $subject, $message, $headers)){
                            ?>
                            <div class="alert alert-success" role="alert">
                                <?php
                                    echo 'Your e-mail (' . $_POST['subscriber_email'] . ') has been added to our mailing list!';
                                ?>
                            </div>
                            <?php
                        }
                        else{

	                        ?>
                            <div class="alert alert-danger" role="alert">
		                        <?php
		                            echo 'There was a problem with your e-mail (' . $_POST['subscriber_email'] . ')';
		                        ?>
                            </div>
	                        <?php
                        }
                    }
                    else{
	                    ?>
                        <div class="alert alert-danger" role="alert">
		                    <?php
		                        echo 'There was a problem with your e-mail (' . $_POST['subscriber_email'] . ')';
		                    ?>
                        </div>
	                    <?php
                    }
                }

            ?>


            <br>
            <br>
<!-------------------------------------------------->

            <?php
                if (have_posts()){

                    while (have_posts()){

                        the_post();
                        the_content();

                    }
                }
            ?>
        </div>

    </article>

<?php
    get_footer();
?>