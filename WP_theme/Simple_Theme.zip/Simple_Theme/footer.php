<footer class="footer text-center py-2 theme-bg-dark">

	<p class="copyright"><a href="https://m-shiaralizadeh.ir">Follow US</a></p>
    <?php dynamic_sidebar('side_1') ?>

</footer>

</div>

<!-- Footer -->

<?php
	wp_footer();
?>

</body>
</html>

