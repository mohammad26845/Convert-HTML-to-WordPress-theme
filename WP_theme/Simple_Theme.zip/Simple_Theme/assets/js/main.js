
$(function () {
    $(window).on('scroll', function () {

        if ($(this).scrollTop() >= 100){
                $('.page-title').addClass("sticky");
        }
        else if($(this).scrollTop() < 10){
                $('.page-title').removeClass("sticky");

        }
    });
});


