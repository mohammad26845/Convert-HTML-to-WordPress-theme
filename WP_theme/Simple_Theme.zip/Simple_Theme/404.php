<?php
get_header();
?>

	<div class="main-wrapper">
	<header class="page-title theme-bg-light text-center gradient py-5">
		<h1 class="heading">BLOG</h1>
	</header>


	<article class="content px-3 py-5 p-md-5">
		<h2>OOPS.... page not found</h2>
	</article>




<?php
get_footer();
?>